/*****************************************************************************
*  Copyright 2011 Sergey Shekyan, Victor Agababov
*
*  Licensed under the Apache License, Version 2.0 (the "License");
*  you may not use this file except in compliance with the License.
*  You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* *****************************************************************************/

/*****
 * Author: Sergey Shekyan shekyan@gmail.com
 *         Victor Agababov vagababov@gmail.com
 *
 * Slow HTTP attack vulnerability test tool
 * https://github.com/shekyan/slowhttptest
 *****/

#include "config.h"
#include <getopt.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <memory>
#include <cctype>

#include "slowlog.h"
#include "slowhttptest.h"

#define DEFAULT_URL "http://localhost/"

#ifdef HAVE_CXX11
#  define UNIQUE_PTR std::unique_ptr
#else
#  define UNIQUE_PTR std::auto_ptr
#endif

static void info() {
  printf("Try \'%s -h\' for more information\n", PACKAGE);
}
static void usage() {
  printf(
      "\n" PACKAGE ", a tool to test for slow HTTP "
      "DoS vulnerabilities - version " VERSION "\n"
      "Usage: "
      PACKAGE " [options ...]"
      "\n"
      "Test modes:\n"
      "  -H               slow headers a.k.a. Slowloris (default)\n"
      "  -B               slow body a.k.a R-U-Dead-Yet\n"
      "  -R               range attack a.k.a Apache killer\n"
      "  -X               slow read a.k.a Slow Read\n"
      "\nReporting options:\n\n"
      "  -g               generate statistics with socket state changes (off)\n"
      "  -o file_prefix   save statistics output in file.html and file.csv (-g required)\n"
      "  -v level         verbosity level 0-4: Fatal, Info, Error, Warning, Debug\n"
      "\nGeneral options:\n\n"
      "  -c connections   target number of connections (50)\n"
      "  -i seconds       interval between followup data in seconds (10)\n"
      "  -l seconds       target test length in seconds (240)\n"
      "  -r rate          connections per seconds (50)\n"
      "  -s bytes         value of Content-Length header if needed (4096)\n"
      "  -t verb          verb to use in request, default to GET for\n"
      "                   slow headers and response and to POST for slow body\n"
      "  -u URL           absolute URL of target (http://localhost/)\n"
      "  -x bytes         max length of each randomized name/value pair of\n"
      "                   followup data per tick, e.g. -x 2 generates\n"
      "                   X-xx: xx for header or &xx=xx for body, where x\n"
      "                   is random character (32)\n"
      "  -f content-type  value of Content-type header (application/x-www-form-urlencoded)\n"
      "  -m accept        value of Accept header (text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5)\n"
      "\nProbe/Proxy options:\n\n"
      "  -d host:port     all traffic directed through HTTP proxy at host:port (off)\n"
      "  -e host:port     probe traffic directed through HTTP proxy at host:port (off)\n"
      "  -p seconds       timeout to wait for HTTP response on probe connection,\n"
      "                   after which server is considered inaccessible. \n"
      "                   This is also the interval at which probes are sent (5)\n"
      "  -j cookies       value of Cookie header (ex.: -j \"user_id=1001; timeout=9000\")\n"
      "  -1 header        value of custom header (ex.: -1 \"X-Custom-Header: someheader123\")\n"
      "\nRange attack specific options:\n\n"
      "  -a start        left boundary of range in range header (5)\n"
      "  -b bytes        limit for range header right boundary values (2000)\n"
      "\nSlow read specific options:\n\n"
      "  -k num          number of times to repeat same request in the connection. Use to\n"
      "                  multiply response size if server supports persistent connections (1)\n"
      "  -n seconds      interval between read operations from recv buffer in seconds (1)\n"
      "  -w bytes        start of the range advertised window size would be picked from (1)\n"
      "  -y bytes        end of the range advertised window size would be picked from (512)\n"
      "  -z bytes        bytes to slow read from receive buffer with single read() call (5)\n"
      "\nEnvironment variables:\n\n"
      "  SSL_CERT         client certificate (PEM format)\n"
      "  SSL_KEY          client private key (PEM format)\n"
      );
}

static bool check_window_range(int a,int b) {
  if(a > b) {
    printf("Error: start value of the advertised window range "
       "is higher (%d) than the end value (%d)\r\n", a, b);
    info();
    return  false;
  }
  return true;
}

// The upper bounds passed here are the same table ng enforces in
// ng/src/config/cli.cpp, so a flag means the same thing in both tools.
// ng/tests/test_flag_limits.py compares the two and fails if they drift.
// -c is the one deliberate exception; see below.
static bool parse_int(int &val, long max = INT_MAX) {
  long tmp = strtol(optarg, 0, 10);
  if(tmp == 0) { //not last empty argument
    printf("Option -%c requires an argument.\n", optopt);
    info();
    return false;
  } else if(tmp < 0 || tmp > max) {
    printf("Error: invalid -%c value %ld, max: %ld\r\n",optopt, tmp, max);
    info();
    return false;
  } else {
    val = static_cast<int>(tmp);
    return true;
  }
}

// Option values are copied into fixed-size buffers. Truncating one silently is
// worse than refusing it: a cut Cookie authenticates as nobody, so the run goes
// on to attack the unauthenticated code path while every report it writes says
// the request was sent as asked. A tool whose whole output is a claim about
// what the server did must not quietly change what it asked the server.
static bool copy_opt(char *dst, size_t cap, const char *src) {
  size_t len = strlen(src);
  if(len >= cap) {
    printf("Error: -%c value is %lu bytes, max: %lu\r\n", optopt,
           (unsigned long) len, (unsigned long) (cap - 1));
    info();
    return false;
  }
  memcpy(dst, src, len + 1);
  return true;
}

// global flag to indicite if we need to run
volatile sig_atomic_t g_running = 1;

void int_handler(int param) {
  g_running = 0;
}

using slowhttptest::slowlog_init;
using slowhttptest::slowlog;
using slowhttptest::SlowHTTPTest;
using slowhttptest::SlowTestType;
using slowhttptest::ProxyType;

int main(int argc, char **argv) {

  if (argc < 1) {
    info();
    return -1;
  }
  // 8 KB for anything that carries a caller-supplied header value or URL. The
  // old 1 KB was below what real deployments use: a JWT in -j, a signed URL
  // with a long query string, or an Authorization header in -1 all exceed it,
  // and each was being silently cut. 8 KB matches the default request-header
  // limit of Apache and nginx, so a value this tool accepts is one a server
  // will too.
  //
  // -d/-e take a host:port and -t an HTTP verb; neither has a real case for
  // more room, and a bound that reflects the input is worth more than a
  // uniform one.
  char url[8192] = { 0 };
  // -o, the report base name. Bounded like a filename rather than like a header
  // value: it is concatenated with ".csv"/".html" into a fixed buffer
  // downstream, so its ceiling belongs to the filesystem, not to HTTP.
  char report_base[1024] = { 0 };
  char proxy[1024] = { 0 };
  char verb[16] = { 0 };
  char content_type[8192] = { 0 };
  char accept[8192] = { 0 };
  char cookie[8192] = { 0 };
  char header[8192] = { 0 };
  // default values
  int conn_cnt            = 50;
  int content_length      = 4096;
  int duration            = 240;
  int interval            = 10;
  int max_random_data_len = 32;
  int probe_interval      = 5;
  int range_start         = 5;
  int range_limit         = 2000;
  int rate                = 50;
  int read_interval       = 1;
  int read_len            = 5;
  int pipeline_factor     = 1;
  int debug_level         = LOG_INFO;
  bool  need_stats        = false;
  int window_upper_limit  = 512;
  int window_lower_limit  = 1;
  SlowTestType type = slowhttptest::eHeader;
  ProxyType proxy_type = slowhttptest::eNoProxy;
  long tmp;
  int o;
  while((o = getopt(argc, argv, ":HBRXgha:b:c:d:e:f:i:j:k:l:m:n:o:p:r:s:t:u:v:w:x:y:z:1:")) != -1) {
    switch (o) {
      case 'a':
        if(!parse_int(range_start, 65539))
          return -1;
        break;
      case 'b':
        if(!parse_int(range_limit, 524288))
          return -1;
        break;
      case 'c':
        // Deliberately lower than ng's cap, and not drift: this build may be
        // using select(), which cannot watch a descriptor at or above
        // FD_SETSIZE at all. ng has kqueue/epoll/poll and no such ceiling.
#ifdef HAVE_POLL
        if(!parse_int(conn_cnt, 65539))
#else
        if(!parse_int(conn_cnt, 1024))
#endif
          return -1;
        break;
      case 'd':
        if(!copy_opt(proxy, sizeof(proxy), optarg))
          return -1;
        proxy_type = slowhttptest::eHTTPProxy;
        break;
      case 'e':
        if(!copy_opt(proxy, sizeof(proxy), optarg))
          return -1;
        proxy_type = slowhttptest::eProbeProxy;
        break;
      case 'f':
        if(!copy_opt(content_type, sizeof(content_type), optarg))
          return -1;
        break;
      case 'h':
        usage();
        return 1;
        break;
      case 'H':
        type = slowhttptest::eHeader;
        break;
      case 'B':
        type = slowhttptest::ePost;
        break;
      case 'R':
        type = slowhttptest::eRange;
        break;
      case 'X':
        type = slowhttptest::eSlowRead;
        break;
      case 'g':
        need_stats = true;
        break;
      case 'i':
        if(!parse_int(interval))
          return -1;
        break;
      case 'j':
        if(!copy_opt(cookie, sizeof(cookie), optarg))
          return -1;
        break;
      case '1':
        if(!copy_opt(header, sizeof(header), optarg))
          return -1;
        break;
      case 'k':
        if(!parse_int(pipeline_factor, 1024))
          return -1;
        break;
      case 'l':
        if(!parse_int(duration))
          return -1;
        break;
      case 'm':
        if(!copy_opt(accept, sizeof(accept), optarg))
          return -1;
        break;
      case 'n':
        if(!parse_int(read_interval))
          return -1;
        break;
      case 'o':
        if(!copy_opt(report_base, sizeof(report_base), optarg))
          return -1;
        break;
      case 'p':
        if(!parse_int(probe_interval, 3600))
          return -1;
        break;
      case 'r':
        if(!parse_int(rate, 100000))
          return -1;
        break;
      case 's':
        if(!parse_int(content_length))
          return -1;
        break;
      case 't':
        if(!copy_opt(verb, sizeof(verb), optarg))
          return -1;
        break;
      case 'u':
        if(!copy_opt(url, sizeof(url), optarg))
          return -1;
        break;
      case 'v':
        tmp = strtol(optarg, 0, 10);
        if(0 <= tmp && tmp <= 4) {
          debug_level = static_cast<int>(tmp);
        } else {
          debug_level = LOG_FATAL;
        }
        break;
      case 'w':
        if(!parse_int(window_lower_limit, 1048576))
          return -1;
        break;
      case 'x':
        // Bounded because it is not: -x 2000000000 overflowed
        // extra_data_max_len_ * 2 and then threw std::length_error out of
        // basic_string, which nothing catches. A followup name/value pair has
        // no business being larger than a header, and every other size option
        // here is capped in this range.
        if(!parse_int(max_random_data_len, 65536))
          return -1;
        else
          if(max_random_data_len < 2) max_random_data_len = 2;
        break;
      case 'y':
        if(!parse_int(window_upper_limit, 1048576))
          return -1;
        break;
      case 'z':
        if(!parse_int(read_len, 1048576))
          return -1;
        break;
      case '?':
        printf("Illegal option -%c\n", optopt);
        info();
        return -1;
        break;
      default:
        printf("Option -%c requires an argument.\n", optopt);
        info();
        return -1;
    }
  }
  int index;
  for (index = optind; index < argc; index++) {
    printf ("Non-option argument %s\n", argv[index]);
    info();
    return -1;
  }
  if(slowhttptest::eSlowRead == type 
      && !check_window_range(window_lower_limit, window_upper_limit))
    return -1;
  if(!strlen(url)) {
    strncpy(url, DEFAULT_URL, sizeof(url));
  }
  signal(SIGPIPE, SIG_IGN);
  signal(SIGINT, &int_handler);
  slowlog_init(debug_level, NULL);
  UNIQUE_PTR<SlowHTTPTest> slow_test(
      new SlowHTTPTest(rate, duration, interval,
      conn_cnt, max_random_data_len, content_length,
      type, need_stats, pipeline_factor, probe_interval,
      range_start, range_limit, read_interval, read_len,
      window_lower_limit, window_upper_limit, proxy_type, debug_level));
  if(!slow_test->init(url, verb, report_base, proxy, content_type, accept, cookie, header)) {
    slowlog(LOG_FATAL, "%s: error setting up slow HTTP test\n", __FUNCTION__);
    return -1;
  } else if(!slow_test->run_test()) {
    slowlog(LOG_FATAL, "%s: error running slow HTTP test\n", __FUNCTION__);
    return -1;
  }
  slow_test->report_final();
  return 0;
}
