// SPDX-License-Identifier: Apache-2.0
// Copyright 2011-2026 Sergey Shekyan and contributors
#include <cstdio>
#include <memory>

#include "slowhttp/attacks/range.hpp"
#include "slowhttp/attacks/slow_body.hpp"
#include "slowhttp/attacks/expect_continue.hpp"
#include "slowhttp/attacks/slow_tls.hpp"
#include "slowhttp/attacks/slow_quic.hpp"
#include "slowhttp/attacks/slow_headers.hpp"
#include "slowhttp/attacks/slow_read.hpp"
#include "slowhttp/attacks/slow_read_h2.hpp"
#include "slowhttp/attacks/rapid_reset.hpp"
#include "slowhttp/attacks/continuation.hpp"
#include "slowhttp/cli.hpp"
#include "slowhttp/config.hpp"
#include "slowhttp/engine.hpp"

int main(int argc, char** argv) {
  slowhttp::Config cfg;
  switch (slowhttp::parse_cli(argc, argv, cfg)) {
    case slowhttp::CliResult::kExit:
      return 0;
    case slowhttp::CliResult::kError:
      return 2;
    case slowhttp::CliResult::kRun:
      break;
  }

  std::unique_ptr<slowhttp::Attack> attack;
  // Kept so the interim-response tally can be reported after the run. It is
  // the half of this mode that only exists on the wire: whether the server
  // agreed to receive the body it is now waiting for.
  slowhttp::ExpectContinue* expect_attack = nullptr;
  switch (cfg.mode) {
    case slowhttp::Mode::SlowHeaders:
      attack.reset(new slowhttp::SlowHeaders(cfg));
      break;
    case slowhttp::Mode::SlowRead:
      if (cfg.http2) {
        auto* h2 = new slowhttp::SlowReadH2(cfg);
        attack.reset(h2);
        if (cfg.log_level >= 1)
          std::fprintf(stderr,
                       "  HTTP/2: %d stream(s) per connection, %zu byte opening"
                       " burst\n",
                       h2->streams_per_connection(), h2->handshake_size());
      } else {
        attack.reset(new slowhttp::SlowRead(cfg));
      }
      break;
    case slowhttp::Mode::SlowBody:
      attack.reset(new slowhttp::SlowBody(cfg));
      break;
    case slowhttp::Mode::ExpectContinue: {
      auto* ec = new slowhttp::ExpectContinue(cfg);
      attack.reset(ec);
      expect_attack = ec;
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  expect 100-continue: %zu byte request announcing a"
                     " %d byte body that never starts\n",
                     ec->request_size(), cfg.content_length);
      break;
    }
    case slowhttp::Mode::SlowTls: {
      auto* st = new slowhttp::SlowTls(cfg);
      attack.reset(st);
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  slow TLS handshake: a %zu byte ClientHello declared and"
                     " dribbled, never completed\n",
                     st->declared_size());
      break;
    }
    case slowhttp::Mode::SlowQuic: {
      auto* sq = new slowhttp::SlowQuic(
          cfg, cfg.quic_complete_hello ? slowhttp::SlowQuic::Hello::Complete
                                       : slowhttp::SlowQuic::Hello::Partial);
      attack.reset(sq);
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  slow QUIC handshake: %s %zu byte ClientHello per"
                     " connection, 1200 byte datagrams\n",
                     cfg.quic_complete_hello ? "complete" : "partial,",
                     sq->hello_size());
      break;
    }
    case slowhttp::Mode::Continuation: {
      auto* cf = new slowhttp::ContinuationFlood(cfg);
      attack.reset(cf);
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  CONTINUATION flood: header block left open, a fragment"
                     " every %llds\n",
                     static_cast<long long>(cfg.interval.count()));
      break;
    }
    case slowhttp::Mode::RapidReset: {
      auto* rr = new slowhttp::RapidReset(cfg);
      attack.reset(rr);
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  rapid reset: %d stream(s) per %lldms per connection\n",
                     rr->per_tick(),
                     static_cast<long long>(rr->tick().count()));
      break;
    }
    case slowhttp::Mode::Range: {
      auto* range = new slowhttp::RangeAttack(cfg);
      attack.reset(range);
      if (cfg.log_level >= 1)
        std::fprintf(stderr,
                     "  range set: %d specs, %zu byte request\n",
                     range->range_count(), range->request_size());
      break;
    }
  }

  slowhttp::Engine engine(cfg, *attack);
  // run() leaves by _exit(); anything to report at the end goes through
  // Attack::summary(), which the engine prints.
  (void)expect_attack;
  return engine.run();
}
