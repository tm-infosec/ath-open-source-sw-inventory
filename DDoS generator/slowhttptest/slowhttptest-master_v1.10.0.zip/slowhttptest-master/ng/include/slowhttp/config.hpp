// SPDX-License-Identifier: Apache-2.0
// Copyright 2011-2026 Sergey Shekyan and contributors
#ifndef SLOWHTTP_CONFIG_HPP_
#define SLOWHTTP_CONFIG_HPP_

#include <chrono>
#include <string>
#include <utility>
#include <vector>

namespace slowhttp {

enum class Mode { SlowHeaders, SlowBody, SlowRead, Range, RapidReset,
                 Continuation, ExpectContinue, SlowTls, SlowQuic };

const char* mode_name(Mode m);

extern const char* const kToolVersion;
extern const char* const kProjectUrl;

// The default User-Agent, and the only one used unless the operator asks for
// something else.
//
// This is a testing tool, not an attack tool, and it says so on every request.
// Following the long-standing crawler convention (`name/version (+url)`), the
// traffic is trivially identifiable in the target's own logs: whoever is on the
// receiving end can look it up, correlate it with a scheduled test, and tell it
// apart from a real incident. Disguising it would make that impossible, and the
// people running the target are the people this tool exists to help.
extern const char* const kDefaultUserAgent;

// Current desktop browser agents -- Chrome, Firefox, Safari -- used only when
// --random-user-agent is given.
//
// The legitimate reason to reach for these is that CDNs and WAFs route and
// rate-limit on User-Agent, so a self-identifying agent can be shed before it
// reaches the service and the run then measures the bot-mitigation layer instead.
// When the question is specifically "how does this behave for browser traffic",
// this answers it. It is opt-in because that is a narrower question than the one
// the tool is usually asked, and because the honest default should not require
// an argument.
//
// One agent is chosen per run rather than per connection: mixing agents the
// target may treat differently would make the result unattributable. Whichever
// is used is recorded in the report.
extern const char* const kUserAgents[3];
constexpr int kUserAgentCount = 3;

// Parsed target endpoint.
struct Target {
  std::string scheme = "http";
  std::string host;
  std::string port = "80";
  std::string path = "/";

  bool tls() const { return scheme == "https"; }

  // `host` is stored unbracketed (as the resolver wants it), but an IPv6 literal
  // has to go back inside brackets anywhere it appears in HTTP syntax, or the
  // colons in the address are indistinguishable from the port separator.
  bool ipv6_literal() const { return host.find(':') != std::string::npos; }
  std::string host_in_url() const {
    return ipv6_literal() ? "[" + host + "]" : host;
  }

  // "host:port", the form a CONNECT request and an absolute URI want.
  std::string authority() const { return host_in_url() + ":" + port; }

  std::string default_port() const { return tls() ? "443" : "80"; }

  // What belongs in the Host header. The port is included whenever it is not
  // the scheme's default (RFC 9110 §7.2). Omitting it is not cosmetic: name-based
  // virtual hosts and Host-routing reverse proxies will send the request to a
  // different backend than the one being tested, and strict servers answer 400 --
  // either way the run measures something other than the intended target.
  std::string host_header() const {
    return port == default_port() ? host_in_url() : authority();
  }
};

// An HTTP proxy endpoint. Empty host means "not configured".
struct ProxyEndpoint {
  std::string host;
  std::string port;

  bool enabled() const { return !host.empty(); }
};

// Which HTTP status codes should fail the CI criterion.
//
// Deliberately kept separate from the availability outcome. A 503 *is* a served
// response: the server answered, and calling that "denied" would conflate "it
// refused me" with "it never answered me". But plenty of operators do care about
// a 503 flood, so this gives them a gate without corrupting the measurement.
struct StatusMatcher {
  std::vector<int> exact;    // e.g. 503
  std::vector<int> classes;  // e.g. 5 for any 5xx

  bool empty() const { return exact.empty() && classes.empty(); }

  bool matches(int code) const {
    if (code < 0) return false;
    for (int e : exact)
      if (e == code) return true;
    for (int c : classes)
      if (code / 100 == c) return true;
    return false;
  }
};

// Capacity ("staircase") search knobs. The engine holds `start` connections,
// probes, then steps up by `step` until the service stops answering, which
// brackets the denial threshold between the last level that held and the first
// that did not.
struct CapacityPlan {
  bool enabled = false;
  int start = 32;                       // first level
  int step = 32;                        // increment between levels
  int max = 0;                          // ceiling; 0 => Config::connections
  std::chrono::seconds hold{15};        // time held at each level
};

// Full test configuration. Field names mirror the classic CLI flags so the flag
// parser stays a thin mapping and existing muscle memory carries over.
struct Config {
  Target target;
  Mode mode = Mode::SlowHeaders;

  int connections = 50;                  // -c  target concurrent connections
  int rate = 50;                         // -r  new connections per second

  // --connect-timeout: how long a connection may sit unestablished before it is
  // dropped and the slot reused. 0 leaves it to the OS.
  //
  // The OS default is far too long here: macOS retries a SYN for 75 seconds, so
  // against a target that is dropping them, slots fill with connections that
  // will never complete and contribute nothing. Recycling them keeps the SYN
  // pressure up and, incidentally, stops thousands of half-open sockets
  // accumulating -- which is its own problem, since the kernel is slow to reap
  // a process holding them.
  // AF_UNSPEC, AF_INET or AF_INET6. Pins which resolved address family a run
  // uses. Left unpinned, the resolver's first answer wins -- and it is free to
  // give a different one each time, which silently moves a run onto a different
  // network path between invocations.
  int address_family = 0;  // 0 == AF_UNSPEC

  // HTTP/2. Only meaningful with slow read for now: the other three modes rest
  // on HTTP/1.1 framing with no direct HTTP/2 equivalent, and the nearest
  // analogues (a CONTINUATION flood in place of slow headers) are separate
  // attacks rather than the same attack over different framing.
  bool http2 = false;    // --http2
  int h2_streams = 100;  // --h2-streams, streams pinned per connection

  // --window-trickle N: with slow read over HTTP/2, hold the stream windows at
  // N bytes and replenish them by N on every -n interval, instead of opening
  // them as far as the protocol allows.
  //
  // Without it the throttle is SO_RCVBUF, which the kernel is free to ignore --
  // it routinely grants a buffer hundreds of times larger than -w/-y asked for,
  // and the run then measures the kernel's autotuning rather than the target.
  // A flow-control window is not advisory: the server may not exceed it. It
  // also keeps each stream demonstrably progressing, so a server-side send
  // timeout -- the defence that does catch a stalled reader -- never fires.
  // 0 leaves the window wide open, which is the original behaviour.
  int window_trickle = 0;
  // --h2-reset-rate: streams opened and cancelled per second, per
  // connection. Bounded by default because this is a load generator
  // aimed at a known amplifier: with -c 50 the default is already 5000
  // requests a second that a vulnerable server will process in full.
  int h2_reset_rate = 100;

  std::chrono::seconds connect_timeout{10};

  // --max-connecting: ceiling on connections simultaneously mid-handshake.
  // 0 removes the limit.
  //
  // Flooding a slow-accepting target is a legitimate thing to test -- exhausting
  // an accept queue is a real attack -- so this does not exist to prevent it.
  // It exists because the cost of holding half-open sockets has a knee in it.
  // Measured on macOS, time for the OS to reap the process on Ctrl-C against a
  // target that answers no SYNs at all:
  //
  //     2500 in flight   0.0 s      7000 in flight    7.4 s
  //     5000 in flight   0.6 s      9000 in flight   14.2 s
  //     6000 in flight   3.1 s     10000 in flight   23.5 s
  //
  // Free below five thousand, expensive above it. The default sits at the knee,
  // so the usual case pays nothing and an operator who wants a larger flood asks
  // for it. Against a target that accepts normally this never binds at all:
  // handshakes finish in milliseconds, so even a fast ramp keeps only a few
  // hundred in flight.
  int max_connecting = 5000;
  std::chrono::seconds duration{240};    // -l  total test length
  std::chrono::seconds interval{10};     // -i  followup dribble interval
  int max_random_data_len = 32;          // -x  max size of each random name/value
  int content_length = 4096;             // -s  Content-Length for body modes

  // --chunked: frame the body with Transfer-Encoding: chunked instead of
  // promising a Content-Length. The hold is stronger rather than merely
  // different -- a chunked body ends only at the terminating zero-length chunk,
  // which is never sent, so there is no declared length for the server to
  // measure the request against and nothing for -s to say. A server that caps
  // request bodies by Content-Length alone has nothing to cap here.
  bool chunked = false;

  std::string verb;                      // -t  (defaults per mode)
  // -A, or kDefaultUserAgent, or -- with --random-user-agent -- one of
  // kUserAgents picked for the run.
  std::string user_agent;
  bool random_user_agent = false;        // --random-user-agent
  std::string content_type =             // -f
      "application/x-www-form-urlencoded";
  std::string accept =                   // -m
      "text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5";
  std::string cookie;                    // -j
  // Sent on every request, as the classic tool has always done. Override with
  // -1 "Referer: ..."; clear it with --no-referer.
  std::string referer = "TESTING_PURPOSES_ONLY";
  // -1 / --header, repeatable. One flag was never enough: an authenticated
  // target routinely needs an Authorization header *and* a routing or tenant
  // header, and the classic tool's single slot forced people to choose.
  std::vector<std::string> extra_headers;

  // -P / --data: the request body for -B, literal or read from @file. Without it
  // the body is the classic "foo=bar" plus random padding, which endpoints that
  // validate their input reject before the slow-body hold can bite.
  std::string body_data;
  std::string body_data_source;          // "@file" or "literal", for the report

  // Range (-R) specific knobs.
  int range_start = 5;                    // -a  left boundary of each range
  int range_limit = 2000;                 // -b  right boundary ceiling

  // Slow read (-X) specific knobs, names and defaults matching the classic tool.
  std::chrono::seconds read_interval{1};  // -n  delay between read() calls
  int read_len = 5;                       // -z  bytes per read() call
  int window_lower = 1;                   // -w  advertised window range, low end
  int window_upper = 512;                 // -y  advertised window range, high end
  int pipeline_factor = 1;                // -k  repeat the request N times

  // Proxies. -d carries everything (attack + probe); -e carries only the probe,
  // which is how you measure availability from a different network path than the
  // one being saturated.
  ProxyEndpoint proxy;                   // -d  host:port, all traffic
  ProxyEndpoint probe_proxy;             // -e  host:port, probe traffic only
  // --probe-direct: measure availability at the origin rather than through the
  // proxy the attack is using. Without it the probe inherits -d, which answers
  // a different question -- whether the proxy is still serving -- and that is
  // the one a run through a proxy usually answers by accident.
  bool probe_direct = false;

  // Availability probe. `probe_timeout` keeps the classic -p meaning: how long to
  // wait for a response before calling the service unavailable.
  bool probe_enabled = true;
  std::chrono::seconds probe_timeout{5};       // -p
  std::chrono::milliseconds probe_interval{2000};  // --probe-interval
  // A probe slower than this (but still answered) counts as degraded rather than
  // served. Raised at runtime to a multiple of the measured baseline so a target
  // that is simply slow does not read as degraded from the first sample.
  std::chrono::milliseconds degraded_above{1000};

  CapacityPlan capacity;

  // Reporting.
  bool report = false;                   // -g  write a report
  std::string report_base = "slowhttptest-ng";  // -o  base name (.html/.json)
  // Fraction of probes that must be served for the JSON criterion to pass. Used
  // for CI gating; it is a stated threshold, not a claim about the target.
  double availability_threshold = 0.95;  // --avail-threshold

  // --fail-on-status: status codes that additionally fail the criterion. Affects
  // the CI gate only, never the denied/degraded/held outcome.
  StatusMatcher fail_on_status;
  std::string fail_on_status_spec;       // as typed, for the report

  int log_level = 1;                     // -v  0..4 (Fatal..Debug), classic scale
  bool verbose = false;                  // derived: log_level >= 4

  // Resolves the verb actually used given the mode when -t was not supplied.
  // Range defaults to HEAD like the classic tool: the response body is irrelevant
  // to the attack, and HEAD keeps the reply small while the server still pays the
  // full cost of processing the range set.
  std::string effective_verb() const {
    if (!verb.empty()) return verb;
    switch (mode) {
      case Mode::SlowBody: return "POST";
      case Mode::ExpectContinue: return "POST";
      // No HTTP request is ever sent under --slow-tls, but effective_verb()
      // has no way to say "none" and callers would have to special-case it.
      // The banner suppresses the line instead.
      case Mode::SlowTls: return "GET";
      // Same for --slow-quic: the handshake stops long before HTTP/3 has a
      // request to carry a verb in.
      case Mode::SlowQuic: return "GET";
      case Mode::Range:    return "HEAD";
      case Mode::RapidReset: return "GET";
      case Mode::Continuation: return "GET";
      default:             return "GET";
    }
  }

  // True if a -1 header names `name` (case-insensitively), so a default is not
  // emitted alongside the operator's own value and duplicated on the wire.
  bool has_extra_header(const std::string& name) const {
    for (const auto& h : extra_headers) {
      if (h.size() <= name.size()) continue;
      bool same = true;
      for (std::size_t i = 0; i < name.size(); ++i) {
        char a = h[i], b = name[i];
        if (a >= 'A' && a <= 'Z') a = static_cast<char>(a - 'A' + 'a');
        if (b >= 'A' && b <= 'Z') b = static_cast<char>(b - 'A' + 'a');
        if (a != b) { same = false; break; }
      }
      if (same && h[name.size()] == ':') return true;
    }
    return false;
  }

  // Cookie, Referer and every -1 header, already CRLF-terminated and ready to
  // splice into a request. Built here rather than in each attack so the probe
  // cannot end up addressing a different endpoint than the attack does -- with
  // host-routing or tenant headers in play, that would silently measure the
  // wrong service.
  std::string caller_headers() const {
    std::string out;
    if (!cookie.empty()) out += "Cookie: " + cookie + "\r\n";
    for (const auto& h : extra_headers) out += h + "\r\n";
    // A second marker, independent of the User-Agent, carried since the classic
    // tool: whoever is on the receiving end can grep for either. Skipped when the
    // operator supplied their own -- some frameworks check Referer for same-origin
    // on POST, and a value they cannot parse would get the request rejected
    // before the slow-body hold could bite.
    if (!referer.empty() && !has_extra_header("Referer"))
      out += "Referer: " + referer + "\r\n";
    return out;
  }

  // The same headers as caller_headers(), as name/value pairs with names
  // lowercased for HTTP/2, which requires it (RFC 7540 8.1.2).
  //
  // This exists because the three HTTP/2 attacks each built their own header
  // block and none of them carried -1 headers: an operator testing an
  // authenticated or tenant-routed endpoint got their Authorization header on
  // HTTP/1.1 and silently not on h2, so the attack hit a different endpoint
  // from the one they named and the report said nothing.
  //
  // Connection-specific headers are dropped rather than encoded. They are
  // malformed in HTTP/2 (RFC 7540 8.1.2.2) and a server is entitled to reset
  // the stream, which would look like the attack working.
  std::vector<std::pair<std::string, std::string>> caller_headers_h2() const {
    std::vector<std::pair<std::string, std::string>> out;
    auto lower = [](std::string s) {
      for (char& c : s)
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
      return s;
    };
    auto connection_specific = [](const std::string& n) {
      return n == "connection" || n == "keep-alive" || n == "proxy-connection" ||
             n == "transfer-encoding" || n == "upgrade" || n == "te";
    };
    if (!cookie.empty()) out.emplace_back("cookie", cookie);
    for (const auto& h : extra_headers) {
      const auto colon = h.find(':');
      if (colon == std::string::npos) continue;
      std::string name = lower(h.substr(0, colon));
      std::string value = h.substr(colon + 1);
      // Trim the single space conventionally written after the colon.
      std::size_t v = 0;
      while (v < value.size() && (value[v] == ' ' || value[v] == '\t')) ++v;
      value.erase(0, v);
      if (name.empty() || connection_specific(name)) continue;
      out.emplace_back(std::move(name), std::move(value));
    }
    if (!referer.empty() && !has_extra_header("Referer"))
      out.emplace_back("referer", referer);
    return out;
  }

  // The request-target that goes in the request line. A plain-http request sent
  // *to a proxy* must name the absolute URI (RFC 9112 §3.2.2); through a CONNECT
  // tunnel, and with no proxy at all, it is the origin-form path.
  std::string request_target() const {
    if (proxy.enabled() && !target.tls())
      return target.scheme + "://" + target.authority() + target.path;
    return target.path;
  }

  // Where the attack's TCP connections actually go, in the bare form getaddrinfo
  // wants -- no brackets, or resolution of an IPv6 literal fails.
  std::string connect_host() const {
    return proxy.enabled() ? proxy.host : target.host;
  }

  // Same endpoint, formatted for humans. An unbracketed "::1:8080" leaves the
  // reader guessing where the address stops and the port starts.
  std::string connect_endpoint() const {
    if (proxy.enabled()) return proxy.host + ":" + proxy.port;
    return target.authority();
  }
  std::string connect_port() const {
    return proxy.enabled() ? proxy.port : target.port;
  }

  // QUIC is spoken over UDP, so the resolver has to be asked for a datagram
  // socket. Nothing else in the engine changes: a connect()ed UDP socket
  // sends and receives through the same calls a TCP one does.
  bool needs_udp() const { return mode == Mode::SlowQuic; }

  // Whether the ClientHello is finished. Partial leaves the server holding a
  // CRYPTO stream it cannot parse; complete makes it run the key exchange and
  // then wait for a Finished that never arrives.
  bool quic_complete_hello = false;
};

}  // namespace slowhttp

#endif  // SLOWHTTP_CONFIG_HPP_
