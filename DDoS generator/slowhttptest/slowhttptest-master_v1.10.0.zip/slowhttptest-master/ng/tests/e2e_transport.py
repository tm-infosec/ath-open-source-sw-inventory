#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""End-to-end tests for TLS, proxying, the availability probe and the reports.

`e2e_attacks.py` proves the four attacks still do damage. This one proves the
machinery around them is honest:

  * an https target is really attacked over TLS, and through a CONNECT tunnel
  * a plain-http request through a proxy reaches the origin in absolute-URI form
  * the probe measures availability, including through its own separate proxy
  * a proxy that refuses to tunnel is reported as a failure, never as a pass
  * the capacity staircase brackets the denial threshold around the worker count
  * a target that is already unhealthy yields "inconclusive", not a finding
  * the HTML and JSON reports agree and the HTML fetches nothing at view time

The last two are the ones worth having. A tool that reports a confident verdict
when it could not measure anything is worse than one that reports nothing.

Usage: e2e_transport.py <slowhttptest-ng> <mock_slow_server.py> <mock_proxy.py>
"""
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import threading
import sys
import tempfile
import time

WORKERS = 4
failures = []


def fail(name, why):
    print(f"  {name}: FAIL - {why}")
    failures.append(name)


def ok(name, detail=""):
    print(f"  {name}: OK{(' (' + detail + ')') if detail else ''}")


def free_port():
    """A port nothing is listening on, asked of the kernel rather than assumed.

    This used to be a table of fixed numbers, and that made one failure into
    many. When ctest times a run out it kills the harness outright, so the
    finally blocks never run and the mock servers survive. The next run then
    finds its port already open, wait_until(port_open) returns true against the
    *stale* server, and the case proceeds to talk to the wrong process -- which
    hangs, times out, and leaks another pair. Self-sustaining, and it looked for
    days like an intermittent fault in the tool under test.
    """
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


def sweep_stale_servers():
    """Kill mock servers left behind by an earlier run that was killed.

    Belt and braces: dynamic ports already stop a leak from poisoning this run,
    but a leaked server still burns CPU and file descriptors for as long as the
    machine is up.
    """
    import signal as _sig
    try:
        out = subprocess.run(["pgrep", "-f", "tests/mock_"],
                             capture_output=True, text=True).stdout.split()
    except OSError:
        return
    mine = str(os.getpid())
    for pid in out:
        if pid == mine:
            continue
        try:
            os.kill(int(pid), _sig.SIGKILL)
        except (OSError, ValueError):
            pass


def terminate(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def wait_until(predicate, timeout, interval=0.25):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False


def port_open(port, tls=False, timeout=2.0):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout) as s:
            if tls:
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                s = ctx.wrap_socket(s, server_hostname="localhost")
            s.settimeout(timeout)
            s.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\n\r\n")
            return bool(s.recv(128))
    except (OSError, ssl.SSLError, socket.timeout):
        return False


# Runner speed, exported by CMake from SLOWHTTP_TEST_TIMEOUT_SCALE.
#
# Widening ctest's wall-clock budget does not help a case that decides from what
# settles inside a fixed window. The capacity staircase holds each level for a
# few seconds and reads the probes it gets; on a slower runner the level that
# should register as denied can still be ramping when the hold ends, the
# staircase steps past it, and the bracket comes back one step too high.
SCALE = max(1, int(os.environ.get("SLOWHTTP_TEST_TIMEOUT_SCALE", "1")))


def start_server(mock, port, extra=(), workers=WORKERS):
    log = tempfile.NamedTemporaryFile(mode="w+", suffix=".log", delete=False)
    proc = subprocess.Popen(
        [sys.executable, mock, str(port), "--workers", str(workers), *extra],
        stdout=log, stderr=subprocess.DEVNULL)
    return proc, log


def server_served(log_path):
    with open(log_path) as fh:
        m = re.findall(r"served: (\d+)", fh.read())
    return int(m[-1]) if m else 0


def run_tool(tool, args, timeout=180):
    """Runs the tool to completion; returns (exit code, stderr text)."""
    proc = subprocess.Popen([tool, *args], stdout=subprocess.DEVNULL,
                            stderr=subprocess.PIPE)
    try:
        _, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        _, err = proc.communicate()
        return None, err.decode("utf-8", "replace")
    return proc.returncode, err.decode("utf-8", "replace")


def summary_counter(err, name):
    """Reads a counter from the final Done line.

    Not with a bare search: the status line carries the same counters every
    second, so the first match in the stream is always the zero it started at.
    """
    done = [l for l in err.replace(chr(13), chr(10)).split(chr(10))
            if l.startswith("Done (")]
    if not done:
        return None
    m = re.search(name + r"=(\d+)", done[-1])
    return int(m.group(1)) if m else None


def make_cert(tmpdir):
    """Self-signed cert for the mock https server, or None if openssl is absent."""
    if not shutil.which("openssl"):
        return None, None
    cert = os.path.join(tmpdir, "cert.pem")
    key = os.path.join(tmpdir, "key.pem")
    rc = subprocess.run(
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", key, "-out", cert, "-days", "2", "-subj", "/CN=localhost"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
    return (cert, key) if rc == 0 else (None, None)


def tls_supported(tool):
    _, err = run_tool(tool, ["-u", "https://127.0.0.1:1/", "-c", "1", "-l", "1",
                             "--no-probe"], timeout=30)
    return "no TLS backend" not in err


# --------------------------------------------------------------------------
# cases
# --------------------------------------------------------------------------

def case_https(tool, mock, cert, key, port):
    """The attack must actually run over TLS and deny service."""
    server, log = start_server(mock, port, ("--tls-cert", cert, "--tls-key", key))
    try:
        if not wait_until(lambda: port_open(port, tls=True), timeout=15):
            return fail("https attack", "server never became healthy")
        code, err = run_tool(tool, [
            "-u", f"https://127.0.0.1:{port}/", "-c", str(WORKERS * 2),
            "-r", "50", "-i", "5", "-l", "12", "-p", "2",
            "--probe-interval", "1"])
        if "TLS: TLS" not in err:
            return fail("https attack", "tool never reported a TLS session")
        if "SERVICE DENIED" not in err:
            return fail("https attack", "expected the vulnerable server to be denied")
        if code != 0:
            return fail("https attack", f"unexpected exit code {code}")
        m = re.search(r"TLS: (\S+)", err)
        ok("https attack", m.group(1) if m else "")
    finally:
        terminate(server)


def case_https_via_proxy(tool, mock, proxy_script, cert, key, port, pport):
    """https through CONNECT: the tunnel must stay byte-exact or TLS breaks."""
    server, log = start_server(mock, port, ("--tls-cert", cert, "--tls-key", key))
    proxy = subprocess.Popen([sys.executable, proxy_script, str(pport)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_until(lambda: port_open(port, tls=True), timeout=15):
            return fail("https via CONNECT", "server never became healthy")
        time.sleep(1)
        code, err = run_tool(tool, [
            "-u", f"https://127.0.0.1:{port}/", "-d", f"127.0.0.1:{pport}",
            "-c", str(WORKERS * 2), "-r", "50", "-i", "5", "-l", "12",
            "-p", "3", "--probe-interval", "1"])
        if "TLS: TLS" not in err:
            return fail("https via CONNECT", "TLS never completed inside the tunnel")
        if "SERVICE DENIED" not in err:
            return fail("https via CONNECT", "expected service to be denied")
        ok("https via CONNECT")
    finally:
        terminate(proxy)
        terminate(server)


def case_http_via_proxy(tool, mock, proxy_script, port, pport):
    """Plain http through a proxy: absolute-URI form must reach the origin."""
    server, log = start_server(mock, port)
    proxy = subprocess.Popen([sys.executable, proxy_script, str(pport)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("http via proxy", "server never became healthy")
        time.sleep(1)
        before = server_served(log.name)
        code, err = run_tool(tool, [
            "-u", f"http://127.0.0.1:{port}/", "-d", f"127.0.0.1:{pport}",
            "-c", "6", "-r", "50", "-i", "5", "-l", "10", "-p", "2",
            "--probe-interval", "1"])
        if code != 0:
            return fail("http via proxy", f"exit code {code}: {err[-300:]}")
        time.sleep(1.5)
        # The probes are ordinary requests; if absolute-URI rewriting were broken
        # the proxy could not forward them and the origin would serve nothing.
        delta = server_served(log.name) - before
        if delta <= 0:
            return fail("http via proxy",
                        "origin served nothing, so nothing was forwarded")
        ok("http via proxy", f"origin served {delta} forwarded requests")
    finally:
        terminate(proxy)
        terminate(server)


def case_probe_proxy(tool, mock, proxy_script, port, pport):
    """-e sends only the probe through the proxy; the attack still goes direct."""
    server, log = start_server(mock, port)
    proxy = subprocess.Popen([sys.executable, proxy_script, str(pport)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("probe-only proxy", "server never became healthy")
        time.sleep(1)
        code, err = run_tool(tool, [
            "-u", f"http://127.0.0.1:{port}/", "-e", f"127.0.0.1:{pport}",
            "-c", str(WORKERS * 3), "-r", "50", "-i", "5", "-l", "12",
            "-p", "2", "--probe-interval", "1"])
        if "SERVICE DENIED" not in err:
            return fail("probe-only proxy",
                        "probe through the proxy should still have seen denial")
        ok("probe-only proxy")
    finally:
        terminate(proxy)
        terminate(server)


def case_probe_direct(tool, mock, port):
    """--probe-direct must measure the origin, not the proxy the attack uses.

    Both runs point -d at a closed port, so the attack fails identically in
    each and the only thing that differs is where the probe went. Without the
    flag the probe follows -d into the closed port and reports the service
    down; with it the probe reaches the origin and reports it up. Anything that
    routed the probe the same way in both runs would fail one of these.
    """
    server, log = start_server(mock, port)
    dead = "127.0.0.1:9"  # discard, closed on any machine that is not running it
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("probe-direct", "server never became healthy")
        common = ["-u", f"http://127.0.0.1:{port}/", "-d", dead,
                  "-c", "3", "-l", "8", "-p", "2", "--probe-interval", "1"]
        _, follow = run_tool(tool, common)
        _, direct = run_tool(tool, [*common, "--probe-direct"])

        if "available=YES" in follow:
            return fail("probe-direct",
                        "the probe reached something without the flag, so the "
                        "run does not distinguish the two routings")
        if "available=YES" not in direct:
            return fail("probe-direct",
                        "with --probe-direct the probe never reached the "
                        "origin: %s" % direct[-300:])
        # The banner names the endpoint, and it must be the origin rather than
        # the proxy -- "available" alone could be reached the wrong way.
        if f"127.0.0.1:{port} (direct" not in direct:
            return fail("probe-direct",
                        "the banner did not name the origin as the probe "
                        "endpoint: %s" % direct[:600])
        ok("probe-direct", "probe follows -d by default, the origin with the flag")
    finally:
        terminate(server)


def case_probe_direct_conflicts_with_e(tool, port):
    """-e and --probe-direct ask for opposite things, so one must be refused."""
    rc, err = run_tool(tool, ["-u", f"http://127.0.0.1:{port}/",
                              "-e", "127.0.0.1:9", "--probe-direct",
                              "-c", "1", "-l", "2"], timeout=30)
    if rc == 0 or "opposite things" not in err:
        return fail("probe-direct conflicts with -e",
                    "rc=%s, stderr did not explain the conflict: %r"
                    % (rc, err[:200]))
    ok("probe-direct conflicts with -e")


def case_proxy_refuses(tool, mock, proxy_script, cert, key, port, pport):
    """A proxy that will not tunnel must be a loud failure, never a silent pass."""
    server, log = start_server(mock, port, ("--tls-cert", cert, "--tls-key", key))
    proxy = subprocess.Popen([sys.executable, proxy_script, str(pport), "--deny"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(1.5)
        code, err = run_tool(tool, [
            "-u", f"https://127.0.0.1:{port}/", "-d", f"127.0.0.1:{pport}",
            "-c", "4", "-r", "50", "-l", "20", "-p", "2"])
        if code == 0:
            return fail("proxy refuses CONNECT",
                        "exited 0 despite never establishing a connection")
        if "refused CONNECT" not in err:
            return fail("proxy refuses CONNECT",
                        f"no explanation of why setup failed: {err[-300:]}")
        ok("proxy refuses CONNECT", f"exit {code} with the proxy's own reason")
    finally:
        terminate(proxy)
        terminate(server)


# A TLS listener that records, per connection, what ALPN was negotiated and the
# first bytes the client sent. Enough to tell the probe from the attack without
# implementing any of HTTP/2.
def _alpn_spy(port, cert, key, seconds, out):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert, key)
    ctx.set_alpn_protocols(["h2", "http/1.1"])
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(64)
    lock = threading.Lock()

    def handle(conn):
        try:
            t = ctx.wrap_socket(conn, server_side=True)
            alpn = t.selected_alpn_protocol()
            t.settimeout(2)
            try:
                first = t.recv(64)
            except Exception:
                first = b""
            with lock:
                out.append((alpn, bytes(first[:16])))
            t.close()
        except Exception:
            pass

    def accept():
        while True:
            try:
                c, _ = srv.accept()
                threading.Thread(target=handle, args=(c,), daemon=True).start()
            except Exception:
                return

    threading.Thread(target=accept, daemon=True).start()
    time.sleep(seconds)
    srv.close()


def case_probe_alpn(tool, cert, key, port):
    """The probe speaks HTTP/1.1, so it must not negotiate h2.

    Regression test for a run that reported every HTTP/2 attack as total denial
    against a perfectly healthy server. One TLS context was built with
    alpn_h2 = cfg.http2 and handed to both the attack and the probe, so the
    probe negotiated h2 and then sent an HTTP/1.1 request on it. A conforming
    server will not answer that, the probe timed out, and the timeout was
    recorded as the target denying service -- a verdict of SERVICE DENIED for a
    target that was serving normally.
    """
    seen = []
    t = threading.Thread(target=_alpn_spy, args=(port, cert, key, 14, seen),
                         daemon=True)
    t.start()
    time.sleep(0.5)
    subprocess.run([tool, "-X", "--http2", "--h2-streams", "4",
                    "-c", "2", "-r", "2", "-l", "5", "-n", "2",
                    "-p", "2", "--probe-interval", "1",
                    "-u", "https://127.0.0.1:%d/" % port],
                   capture_output=True, text=True, timeout=90)
    t.join(timeout=20)

    if not seen:
        return fail("probe does not inherit h2 ALPN", "no connections observed")
    # The attack opens with the HTTP/2 preface; the probe opens with a method.
    guilty = [(a, f) for (a, f) in seen
              if a == "h2" and (f.startswith(b"GET") or f.startswith(b"HEAD"))]
    if guilty:
        return fail("probe does not inherit h2 ALPN",
                    "a connection negotiated h2 and then sent HTTP/1.1: %s"
                    % guilty[:2])
    probes = [(a, f) for (a, f) in seen
              if f.startswith(b"GET") or f.startswith(b"HEAD")]
    if not probes:
        return fail("probe does not inherit h2 ALPN",
                    "no probe connection seen, so nothing was proven: %s"
                    % seen[:3])
    ok("probe does not inherit h2 ALPN",
       "%d probe connection(s), none on h2" % len(probes))


def _hello_spy(port, cert, key, seconds, seen):
    """A TLS listener that records what each connection delivered.

    Feeds the incoming bytes to OpenSSL through a memory BIO instead of a
    socket, because the question is not whether the handshake finished -- under
    TLS 1.3 it could not finish anyway, since the client's Finished never comes
    -- but whether the ClientHello was ever *complete*. OpenSSL answers that by
    writing a ServerHello into the outgoing BIO, and by staying silent until
    then. Outgoing bytes therefore mean the hello arrived in full, which is the
    one thing this mode must never do.
    """
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert, key)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(64)
    srv.settimeout(0.5)
    conns = []
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            c, _ = srv.accept()
        except (socket.timeout, OSError):
            c = None
        if c is not None:
            c.setblocking(False)
            inc, out = ssl.MemoryBIO(), ssl.MemoryBIO()
            conns.append([c, ctx.wrap_bio(inc, out, server_side=True), inc, out,
                          0, False])
        for entry in conns:
            sock, obj, inc, out, total, replied = entry
            try:
                data = sock.recv(65536)
            except (BlockingIOError, OSError):
                data = None
            if data:
                entry[4] = total + len(data)
                inc.write(data)
                try:
                    obj.do_handshake()
                except ssl.SSLWantReadError:
                    pass
                except ssl.SSLError:
                    pass
                if out.pending:
                    entry[5] = True
                    out.read()
        time.sleep(0.1)
    for sock, _, _, _, total, replied in conns:
        seen.append((total, replied))
        try:
            sock.close()
        except OSError:
            pass
    srv.close()


def case_slow_tls(tool, cert, key, port):
    """--slow-tls must dribble a ClientHello and never complete it.

    Two failure modes this rules out. If the hello were completed, the server
    would answer with a ServerHello and the connection would leave the
    handshake -- the mode would be testing an ordinary TLS connection. If the
    tool sent nothing at all, every assertion about "holding" would be vacuous,
    so the bytes actually delivered are checked too.
    """
    seen = []
    conns = 6
    t = threading.Thread(target=_hello_spy,
                         args=(port, cert, key, 26, seen), daemon=True)
    t.start()
    time.sleep(0.5)
    # -x is deliberately large enough that the run *could* deliver the whole
    # hello. With a small -x the 16 KB hello cannot drain inside the run, and
    # then "no ServerHello" is true whether or not the last byte is withheld --
    # the test would pass against a tool that completes the handshake.
    rc, err = run_tool(tool, ["--slow-tls", "-u", "https://127.0.0.1:%d/" % port,
                              "-c", str(conns), "-i", "1", "-x", "2000",
                              "-l", "20", "--no-probe"], timeout=90)
    t.join(timeout=30)

    if not seen:
        return fail("slow tls holds the handshake", "no connections observed")
    replied = [n for (n, r) in seen if r]
    if replied:
        return fail("slow tls holds the handshake",
                    "%d connection(s) got a ServerHello, so the ClientHello was "
                    "delivered in full" % len(replied))
    # A record header alone is 9 bytes. Requiring well past that proves the
    # dribble ran rather than the connection merely opening and stalling.
    # The hello must have been delivered to the very end, or "it never
    # completed" says nothing: an undrained hello cannot complete either way.
    drained = [n for (n, _) in seen if n >= 16000]
    if not drained:
        return fail("slow tls holds the handshake",
                    "no connection got near the end of the hello, so stopping "
                    "short was never actually tested: %s" % seen[:4])

    ready = summary_counter(err, "attack_ready")
    closed = summary_counter(err, "peer_closed")
    if ready != conns or closed != 0:
        return fail("slow tls holds the handshake",
                    "attack_ready=%s peer_closed=%s, wanted %d and 0"
                    % (ready, closed, conns))
    if "TLS:" not in err or "refused" not in err:
        return fail("slow tls holds the handshake",
                    "the run did not report whether the handshake was refused")
    ok("slow tls holds the handshake",
       "%d connection(s), %d of %d bytes delivered, no ServerHello"
       % (len(seen), max(n for (n, _) in seen), 16389))


def case_slow_tls_refuses_cleartext(tool, port):
    """An http:// URL has nothing to hold, and the tool must say so."""
    rc, err = run_tool(tool, ["--slow-tls", "-u", "http://127.0.0.1:%d/" % port,
                              "-c", "1", "-l", "2"], timeout=30)
    if rc == 0 or "needs an https" not in err:
        return fail("slow tls refuses cleartext",
                    "rc=%s, stderr did not explain the refusal: %r"
                    % (rc, err[:200]))
    ok("slow tls refuses cleartext")


def case_capacity(tool, mock, port):
    """The staircase must bracket the threshold around the server's worker count."""
    server, log = start_server(mock, port, workers=8)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("capacity bracket", "server never became healthy")
        code, err = run_tool(tool, [
            "-u", f"http://127.0.0.1:{port}/", "-c", "32", "-r", "50", "-i", "5",
            "-p", "2", "--probe-interval", "1", "--capacity",
            "--capacity-start", "4", "--capacity-step", "4",
            "--capacity-max", "16", "--capacity-hold", str(5 * SCALE)])
        m = re.search(r"denial threshold: (\d+) < n <= (\d+)", err)
        if not m:
            return fail("capacity bracket", f"no bracket reported: {err[-400:]}")
        lo, hi = int(m.group(1)), int(m.group(2))
        # 8 workers: the level that pins all of them is where service stops.
        if not (lo < 8 <= hi):
            return fail("capacity bracket",
                        f"bracket {lo} < n <= {hi} does not contain the 8 workers")
        ok("capacity bracket", f"{lo} < n <= {hi}")
    finally:
        terminate(server)


def case_inconclusive(tool, mock, port):
    """An already-unhealthy target must not be reported as a finding.

    The server is started with no workers at all, so connections sit in the
    listen backlog and nothing is ever answered -- including the baseline probes.
    The tool must decline to conclude rather than claim it caused the outage.
    """
    server, log = start_server(mock, port, workers=0)
    try:
        time.sleep(1.5)
        code, err = run_tool(tool, [
            "-u", f"http://127.0.0.1:{port}/", "-c", "4", "-r", "50", "-l", "10",
            "-p", "1", "--probe-interval", "1"])
        if "INCONCLUSIVE" not in err:
            return fail("unhealthy baseline",
                        f"expected INCONCLUSIVE, got: {err[-400:]}")
        if "SERVICE DENIED" in err:
            return fail("unhealthy baseline",
                        "claimed a denial it could not have caused")
        ok("unhealthy baseline", "declined to conclude")
    finally:
        terminate(server)


def case_local_limit_not_blamed_on_target(tool, mock, port):
    """A local descriptor limit must never be reported as a problem with the target.

    This is a regression test for a real misdiagnosis: with the stock macOS soft
    limit of 256 descriptors, every socket() failed with EMFILE, and the tool
    said "the target may be down, firewalled, on another port" about a server
    that was answering curl perfectly well. Being wrong in that direction sends
    the operator to debug the wrong machine.
    """
    server, log = start_server(mock, port)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("local limit not blamed on target", "server never healthy")

        # Hard-cap the child so the limit genuinely cannot be raised.
        def cap_fds():
            import resource
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))

        proc = subprocess.Popen(
            [tool, "-u", f"http://127.0.0.1:{port}/", "-c", "10000", "-r", "1000",
             "-l", "8", "--no-probe"],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, preexec_fn=cap_fds)
        _, err_b = proc.communicate(timeout=120)
        err = err_b.decode("utf-8", "replace")

        if proc.returncode == 0:
            return fail("local limit not blamed on target",
                        "exited 0 despite being unable to run the test")
        if "file descriptor" not in err:
            return fail("local limit not blamed on target",
                        f"never mentions descriptors: {err[-300:]}")
        if "ulimit" not in err:
            return fail("local limit not blamed on target",
                        "does not say how to fix it")
        # The specific wrong answer this test exists to prevent.
        if "target may be down" in err:
            return fail("local limit not blamed on target",
                        "still blames the target for a local limit")
        ok("local limit not blamed on target", "names the descriptor limit")
    finally:
        terminate(server)


def case_refused_blames_target(tool, port):
    """...but a target that really is refusing must still be named as the cause."""
    code, err = run_tool(tool, [
        "-u", f"http://127.0.0.1:{port}/", "-c", "5", "-r", "50", "-l", "8",
        "--no-probe"])
    if code == 0:
        return fail("refusal blamed on target", "exited 0 with nothing listening")
    if "refused" not in err.lower():
        return fail("refusal blamed on target",
                    f"does not report the refusal: {err[-300:]}")
    # Must not misfile a genuine target problem as a local one.
    if "THIS machine" in err:
        return fail("refusal blamed on target",
                    "blamed the local machine for the target refusing")
    ok("refusal blamed on target")


def case_interrupt(tool, mock, port, tmpdir):
    """Ctrl-C terminates immediately, and writes nothing.

    The SIGINT handler itself does nothing but set a flag and write one
    non-blocking line: no report, no cleanup, nothing that can block inside the
    handler. The exit path then closes connections through the worker pool
    rather than the kernel's serial teardown, which is what keeps "die soon"
    and "leave nothing behind" compatible.

    Both halves matter. That it dies, and that it leaves no report behind from a
    run nobody waited for, since a half-finished report is worse than none.
    """
    import signal as sig
    base = os.path.join(tmpdir, "cancelled")
    server, log = start_server(mock, port, ("--workers", "8"))
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("interrupt", "server never became healthy")

        proc = subprocess.Popen(
            [tool, "-u", f"http://127.0.0.1:{port}/", "-c", "2000", "-r", "2000",
             "-l", "300", "-p", "1", "--probe-interval", "0.5", "-g", "-o", base],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(8)  # past the baseline, into the attack

        t0 = time.time()
        proc.send_signal(sig.SIGINT)
        try:
            proc.communicate(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            return fail("interrupt", "still alive 20s after SIGINT")
        elapsed = time.time() - t0

        # Killed by the signal: Python reports that as a negative signal number,
        # a shell as 128+n. A normal exit code would mean the tool chose to stop
        # on its own terms, which is exactly what was removed.
        if proc.returncode not in (-sig.SIGINT, 130):
            return fail("interrupt",
                        f"exited {proc.returncode}; expected death by SIGINT")
        if elapsed > 5:
            return fail("interrupt", f"took {elapsed:.1f}s to die")
        for ext in (".html", ".json"):
            if os.path.exists(base + ext):
                return fail("interrupt", f"wrote {ext} for a cancelled run")
        ok("interrupt", f"killed in {elapsed:.2f}s, wrote nothing")
    finally:
        terminate(server)


def case_peer_close_detected(tool, mock, port):
    """Connections the server has closed must not be counted as held.

    Slow read deliberately does not watch for readability -- being woken per
    arriving byte is the opposite of the attack -- and the code once assumed
    poll() would report a hangup anyway. It does not: a peer's FIN is a readable
    event, not POLLHUP. So closed connections sat in CLOSE_WAIT, counted as held,
    forever. Observed in the field: 5740 of a reported 10000, with the tool
    saying peer_closed=0.

    That inflates the one number the whole report rests on, and would make a
    server that is shedding load look like one that is being held down.

    Here the server has many workers and a small body, so it answers and closes
    every connection promptly. Every one of them must be noticed.
    """
    server, log = start_server(mock, port, workers=60)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("peer close detected", "server never became healthy")
        code, err = run_tool(tool, [
            "-X", "-u", f"http://127.0.0.1:{port}/", "-c", "50", "-r", "50",
            "-w", "1", "-y", "8", "-z", "5", "-n", "30", "-l", "14",
            "--no-probe"])
        closed = summary_counter(err, "peer_closed")
        if closed is None:
            return fail("peer close detected", f"no counter in output: {err[-200:]}")
        if closed == 0:
            return fail("peer close detected",
                        "reported 0 peer closes against a server that closes "
                        "every connection -- CLOSE_WAIT is going unnoticed")
        # Slots must be recycled too, not merely counted: more connections opened
        # than -c means closed ones were replaced with live ones.
        opened = summary_counter(err, "opened") or 0
        if opened <= 50:
            return fail("peer close detected",
                        f"opened only {opened}; closed slots are not being reused")
        ok("peer close detected", f"{closed} noticed, {opened} slots cycled")
    finally:
        terminate(server)


def case_held_not_overcounted(tool, mock, port):
    """...and the inverse: a peer that has NOT closed must stay counted as held.

    The detection asks the TCP state machine directly, so this guards against it
    being too eager -- a false positive here would silently weaken every attack
    by closing connections that were doing their job.
    """
    server, log = start_server(mock, port, ("--body-bytes", "2000000"), workers=4)
    try:
        if not wait_until(lambda: port_open(port, ), timeout=15):
            return fail("held not overcounted", "server never became healthy")
        code, err = run_tool(tool, [
            "-X", "-u", f"http://127.0.0.1:{port}/", "-c", "12", "-r", "50",
            "-w", "1", "-y", "8", "-z", "5", "-n", "3", "-l", "16",
            "-p", "2", "--probe-interval", "1"])
        closed = summary_counter(err, "peer_closed")
        if closed is None:
            closed = -1
        if closed != 0:
            return fail("held not overcounted",
                        f"closed {closed} connections whose peer was still sending")
        if "SERVICE DENIED" not in err:
            return fail("held not overcounted",
                        "the attack stopped working, so the check is too eager")
        ok("held not overcounted", "peer_closed=0 and service still denied")
    finally:
        terminate(server)


def case_reports(tool, mock, port, tmpdir):
    """HTML and JSON come from one event log, so they must never disagree."""
    base = os.path.join(tmpdir, "report")
    server, log = start_server(mock, port)
    try:
        if not wait_until(lambda: port_open(port), timeout=15):
            return fail("report artifacts", "server never became healthy")
        code, err = run_tool(tool, [
            "-u", f"http://127.0.0.1:{port}/", "-c", str(WORKERS * 3), "-r", "50",
            "-i", "5", "-l", "12", "-p", "2", "--probe-interval", "1",
            "-g", "-o", base])
        html_path, json_path = base + ".html", base + ".json"
        if not (os.path.exists(html_path) and os.path.exists(json_path)):
            return fail("report artifacts", "one or both files were not written")

        with open(json_path) as fh:
            data = json.load(fh)          # must be valid JSON, not almost-JSON
        with open(html_path) as fh:
            html = fh.read()

        # The baseline calibration must actually have run. It measures the
        # target's healthy latency and raises the "degraded" floor to a multiple
        # of it, so a merely slow target is not called degraded from its first
        # sample. It sat dead for the tool's whole life: it was invoked one line
        # before attack_start_s was assigned, and baseline_probes() selects on
        # `p.t < attack_start_s`, so it always sampled an empty set and returned
        # without calibrating. Nothing noticed, because the default floor is
        # reasonable for a fast target -- the damage only showed against a slow
        # one, where every probe read as degraded before the attack began.
        if data["result"].get("baseline_ms") is None:
            return fail("baseline calibration",
                        "baseline_ms is null: calibration did not run")
        ok("baseline calibration",
           f"baseline {data['result']['baseline_ms']} ms, degraded floor "
           f"{data['parameters']['degraded_above_ms']} ms")

        outcome = data["result"]["outcome"]
        if outcome not in ("denied", "degraded", "held", "inconclusive"):
            return fail("report artifacts", f"unknown outcome {outcome!r}")
        if f'"outcome": "{outcome}"' not in html:
            return fail("report artifacts", "HTML and JSON disagree on the outcome")
        if "VULNERABLE" in html:
            return fail("report artifacts",
                        "report frames the result as a property, not an outcome")
        for needed in ("not_ruled_out", "criterion", "denial_threshold"):
            if needed not in data:
                return fail("report artifacts", f"JSON is missing {needed}")
        if not data["not_ruled_out"]:
            return fail("report artifacts", "JSON lists no caveats")
        # Self-contained: nothing may be fetched when the file is opened.
        for bad in ("<script src", "<link ", "cdn.", "googleapis", "gstatic"):
            if bad in html:
                return fail("report artifacts", f"HTML references {bad!r}")
        ok("report artifacts", f"outcome={outcome}, {len(data['not_ruled_out'])} caveats")
    finally:
        terminate(server)


def main():
    sweep_stale_servers()
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    tool, mock, proxy_script = sys.argv[1], sys.argv[2], sys.argv[3]
    tmpdir = tempfile.mkdtemp(prefix="slowhttp-e2e-")

    print("e2e: proxying")
    case_http_via_proxy(tool, mock, proxy_script, free_port(), free_port())
    case_probe_proxy(tool, mock, proxy_script, free_port(), free_port())
    case_probe_direct(tool, mock, free_port())
    case_probe_direct_conflicts_with_e(tool, free_port())

    print("e2e: failure diagnosis")
    case_local_limit_not_blamed_on_target(tool, mock, free_port())
    case_refused_blames_target(tool, 9)

    print("e2e: availability probe and verdict")
    case_inconclusive(tool, mock, free_port())
    case_capacity(tool, mock, free_port())

    print("e2e: connection accounting")
    case_peer_close_detected(tool, mock, free_port())
    case_held_not_overcounted(tool, mock, free_port())

    print("e2e: reporting")
    case_reports(tool, mock, free_port(), tmpdir)
    case_interrupt(tool, mock, free_port(), tmpdir)

    print("e2e: TLS")
    if not tls_supported(tool):
        print("  skipped: this build has no TLS backend")
    else:
        cert, key = make_cert(tmpdir)
        if not cert:
            print("  skipped: openssl not available to make a test certificate")
        else:
            case_https(tool, mock, cert, key, free_port())
            case_https_via_proxy(tool, mock, proxy_script, cert, key, free_port(),
                                 free_port())
            case_proxy_refuses(tool, mock, proxy_script, cert, key, free_port(),
                               free_port())
            case_probe_alpn(tool, cert, key, free_port())
            case_slow_tls(tool, cert, key, free_port())
            case_slow_tls_refuses_cleartext(tool, free_port())

    shutil.rmtree(tmpdir, ignore_errors=True)
    if failures:
        raise SystemExit(f"e2e: {len(failures)} case(s) failed: {', '.join(failures)}")
    print("e2e: all transport and reporting checks passed")


if __name__ == "__main__":
    main()
