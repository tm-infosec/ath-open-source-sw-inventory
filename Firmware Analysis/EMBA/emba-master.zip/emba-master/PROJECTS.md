
# Community projects

In this document we list all known projects around EMBA and EMBArk. Feel free to open issues or a pull request to list your project also in here.


## EMBA-MCP

Model Context Protocol (MCP) server for EMBA firmware analysis. EMBA-MCP exposes EMBA firmware analysis results as structured tools via MCP, allowing LLMs (Claude, ChatGPT, etc.) to query, reason, and correlate firmware security findings programmatically. It parses, normalizes, and reasons over EMBA output.

[Repository](https://github.com/0xbuz3R/EMBA-MCP)

## UTSA Software Capstone Design Project - Spring 2025

P51 Mustang binwalk extractor is a module for EMBA (Embedded Malware Binary Analyzer) to improve the speed and scalability of firmware analysis by performing a depth-first traversal of the file system, using GPU acceleration, and parallelization of file operations.

[Repository](https://github.com/Chaz-Ortiz/EMBA-CS-4613-901)

## EMBA builder

This repository contains code to automate building a dedicated VM for [EMBA](https://www.securefirmware.de/). As EMBA runs best on [Kali Linux](https://www.kali.org/), it uses Kali's own [build script for VM images](https://gitlab.com/kalilinux/build-scripts/kali-vm/) and modifies it to install EMBA.

[Repository](https://github.com/SySS-Research/emba-builder)

## Python modules for EMBA

The Python runner module `S28_python_run` allows users to run Python scripts as EMBA modules. Recommended use cases for this is module code which requires a lot of complex string or data manipulation, as such operations can get quite difficult to implement and later read when using Bash.

Repository - not available anymore

## EMBAbox

This repo provides a Vagrantfile to simply test and to evaluate [EMBA](https://github.com/e-m-b-a/emba)

[Repository](https://github.com/x7-labs/EMBAbox)
