from __future__ import annotations

import getpass
import os
from typing import NamedTuple


class CveEntry(NamedTuple):
    """
    A named tuple that represents a CVE entry.
    """

    cve_id: str
    summary: str
    impact: dict[str, str]
    cpe_entries: list[tuple[str, str, str, str, str]]


def replace_wildcards(attributes: list[str]) -> list[str]:
    """
    Replaces wildcard characters ('*' and '-') with their respective placeholders in the given attributes.
    """
    for index, attribute in enumerate(attributes):
        if attribute == '*':
            attributes[index] = 'ANY'
        elif attribute == '-':
            attributes[index] = 'N/A'
    return attributes


def is_ci():
    return getpass.getuser() == 'vagrant' and os.environ.get('GITHUB_RUNNER_ACTION_TOKEN') is not None
