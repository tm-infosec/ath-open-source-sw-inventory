from __future__ import annotations

import logging
import os
import pickle
from multiprocessing import Process, Value
from threading import Thread
from time import sleep, time
from typing import TYPE_CHECKING, Any, TypeVar

from redis.exceptions import RedisError

import config
from helperFunctions.hash import get_sha256
from storage.redis_interface import RedisInterface

if TYPE_CHECKING:
    from collections.abc import Callable

Task = TypeVar('Task')  # generic Task type; concrete type depends on the listener


def generate_task_id(input_data: Any) -> str:  # noqa: ANN401
    serialized_data = pickle.dumps(input_data)
    return f'{get_sha256(serialized_data)}_{time()}'


def publish_available_analysis_plugins(plugin_dict: dict[str, tuple]) -> None:
    redis = RedisInterface()
    redis.set('analysis_plugins', plugin_dict)


class InterComListener:
    """
    InterCom Listener Base Class
    """

    CONNECTION_TYPE = 'test'  # unique for each listener

    def __init__(self, processing_function: Callable[[Any], None] | None = None):
        self.redis = RedisInterface()
        self.process = None
        self.processing_function = processing_function
        self.stop_condition = Value('i', 0)

    def start(self) -> None:
        self.process = Process(target=self._worker)
        self.process.start()

    def shutdown(self) -> None:
        self.stop_condition.value = 1

    def _worker(self) -> None:
        logging.debug(f'{self.CONNECTION_TYPE} listener started (pid={os.getpid()})')
        while self.stop_condition.value == 0:
            task = self.get_next_task()
            if task is None:
                sleep(config.backend.intercom_poll_delay)
            elif self.processing_function is not None:
                self.processing_function(task)
        logging.debug(f'{self.CONNECTION_TYPE} listener stopped')

    def get_next_task(self):  # noqa: ANN201
        try:
            task_obj = self.redis.queue_get(self.CONNECTION_TYPE)
        except RedisError as exc:
            logging.error(f'Could not get next task: {exc!s}', exc_info=True)
            return None
        if task_obj is not None:
            task, task_id = task_obj
            task = self.pre_process(task, task_id)
            logging.debug(f'{self.CONNECTION_TYPE}: New task received: {task}')
            return task
        return None

    def pre_process(self, task: Task, task_id: str) -> Task:  # noqa: ARG002
        """
        optional pre-processing of a task
        """
        return task


class InterComListenerAndResponder(InterComListener):
    """
    CONNECTION_TYPE and OUTGOING_CONNECTION_TYPE must be implemented by the sub_class
    """

    OUTGOING_CONNECTION_TYPE = 'test'

    def pre_process(self, task: Task, task_id: str) -> Task:
        logging.debug(f'request received: {self.CONNECTION_TYPE} -> {task_id}')
        tread = Thread(target=self._get_response_asynchronously, args=(task, task_id))
        tread.start()
        return task

    def _get_response_asynchronously(self, task, task_id) -> None:  # noqa: ANN001
        response = self.get_response(task)
        self.redis.set(task_id, response)
        logging.debug(f'response sent: {self.OUTGOING_CONNECTION_TYPE} -> {task_id}')

    def get_response(self, task):  # noqa: ANN001, ANN201
        """
        this function must be implemented by the sub_class
        """
        return task
