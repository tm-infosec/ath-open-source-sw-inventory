from __future__ import annotations

import time
from base64 import standard_b64encode
from contextlib import contextmanager
from copy import deepcopy
from http import HTTPStatus
from pathlib import Path
from typing import TYPE_CHECKING

from helperFunctions.fileSystem import get_src_dir
from helperFunctions.tag import TagColor
from objects.file import FileObject
from objects.firmware import Firmware

if TYPE_CHECKING:
    from collections.abc import Callable

    from werkzeug.test import TestResponse


def get_test_data_dir() -> Path:
    """
    Returns the absolute path of the test data directory
    """
    return Path(get_src_dir()) / 'test/data'


def create_test_firmware(
    device_class='Router',
    device_name='test_router',
    vendor='test_vendor',
    bin_path='container/test.zip',
    all_files_included_set=False,
    version='0.1',
):
    fw: Firmware = Firmware.from_path(get_test_data_dir() / bin_path)
    fw.device_class = device_class
    fw.device_name = device_name
    fw.vendor = vendor
    fw.tags = {'test_tag': TagColor.GRAY}

    fw.release_date = '1970-01-01'
    fw.version = version
    processed_analysis = {
        'dummy': {
            'summary': ['sum a', 'fw exclusive sum a'],
            'result': {
                'content': 'abcd',
            },
            'plugin_version': '0',
            'analysis_date': 0.0,
        },
        'unpacker': {
            'result': {
                'plugin_used': 'used_unpack_plugin',
            },
            'plugin_version': '1.0',
            'analysis_date': 0.0,
        },
        'file_type': {
            'result': {
                'mime': 'test_type',
                'full': 'Not a PE file',
            },
            'summary': ['a summary'],
            'plugin_version': '1.0',
            'analysis_date': 0.0,
        },
    }

    fw.processed_analysis.update(processed_analysis)
    if all_files_included_set:
        fw.list_of_all_included_files = set(fw.files_included or [])
        fw.list_of_all_included_files.add(fw.uid)
    return fw


def create_test_file_object(bin_path='get_files_test/testfile1', uid=None, analyses=None):
    fo = FileObject.from_path(get_test_data_dir() / bin_path)
    processed_analysis = {
        'dummy': {
            'summary': ['sum a', 'file exclusive sum b'],
            'result': {
                'content': 'file abcd',
            },
            'plugin_version': '0',
            'analysis_date': '0',
        },
        'file_type': {
            'result': {
                'full': 'Not a PE file',
                'mime': 'test_type',
            },
            'plugin_version': '1.0',
            'analysis_date': '0',
        },
        'unpacker': {
            'result': {
                'file_system_flag': False,
                'plugin_used': 'unpacker_name',
            },
            'plugin_version': '1.0',
            'analysis_date': '0',
        },
    }
    if analyses:
        processed_analysis.update(analyses)
    fo.processed_analysis.update(processed_analysis)
    if uid:
        fo.uid = uid
    return fo


TEST_FW = create_test_firmware(device_class='test class', device_name='test device', vendor='test vendor')
TEST_FW_2 = create_test_firmware(
    device_class='test_class', device_name='test_firmware_2', vendor='test vendor', bin_path='container/test.7z'
)
TEST_TEXT_FILE = create_test_file_object()
TEST_TEXT_FILE.virtual_file_path = {TEST_FW.uid: [TEST_TEXT_FILE.file_name]}
TEST_TEXT_FILE2 = create_test_file_object(bin_path='get_files_test/testfile2')
NICE_LIST_DATA = {
    'uid': TEST_FW.uid,
    'files_included': TEST_FW.files_included,
    'size': TEST_FW.size,
    'mime-type': 'file-type-plugin/not-run-yet',
    'current_virtual_path': [[TEST_FW.uid]],
}
COMPARISON_ID = f'{TEST_FW.uid};{TEST_FW_2.uid}'

TEST_SEARCH_QUERY = {
    '_id': '0000000000000000000000000000000000000000000000000000000000000000_1',
    'search_query': f'{{"_id": "{TEST_FW_2.uid}"}}',
    'query_title': 'rule a_ascii_string_rule',
}


class MockFileObject:
    def __init__(self, uid='abcd_123', file_path='/bin/ls'):
        self.uid = uid
        self.file_path = file_path
        self.processed_analysis = {'file_type': {'result': {'mime': 'application/x-executable'}}}


class CommonDatabaseMock:
    fw_uid = TEST_FW.uid
    fo_uid = TEST_TEXT_FILE.uid
    fw2_uid = TEST_FW_2.uid

    def __init__(self, config=None):
        self.tasks = []
        self.locks = []

    @contextmanager
    def get_read_only_session(self):
        yield None

    def update_view(self, file_name, content):
        pass

    def get_object(self, uid, analysis_filter=None):
        if uid == TEST_FW.uid:
            result = deepcopy(TEST_FW)
            result.processed_analysis = {
                'file_type': {'result': {'mime': 'application/octet-stream', 'full': 'test text'}},
                'mandatory_plugin': {'result': 'mandatory result'},
                'optional_plugin': {'result': 'optional result'},
                'unloaded_plugin': {'result': 'optional result', 'plugin_version': '1.0.0'},
            }
            return result
        if uid == TEST_TEXT_FILE.uid:
            result = deepcopy(TEST_TEXT_FILE)
            result.processed_analysis = {'file_type': {'result': {'mime': 'text/plain', 'full': 'plain text'}}}
            return result
        if uid == self.fw2_uid:
            result = deepcopy(TEST_FW_2)
            result.processed_analysis = {
                'file_type': {'result': {'mime': 'filesystem/cramfs', 'full': 'test text'}},
                'mandatory_plugin': {'result': 'mandatory result'},
                'optional_plugin': {'result': 'optional result'},
            }
            result.release_date = '2000-01-01'
            return result
        return None

    def get_hid(self, uid, root_uid=None):
        return 'TEST_FW_HID'

    def get_device_class_list(self):
        return ['test class']

    def page_compare_results(self):
        return []

    def get_vendor_list(self):
        return ['test vendor']

    def get_device_name_dict(self):
        return {'test class': {'test vendor': ['test device']}}

    def get_number_of_total_matches(self, *_, **__):
        return 10

    def exists(self, uid):
        return uid in (self.fw_uid, self.fo_uid, self.fw2_uid, 'error')

    def uid_list_exists(self, uid_list):
        return set()

    def all_uids_found_in_database(self, uid_list):
        return True

    def get_data_for_nice_list(self, input_data, root_uid):
        return [NICE_LIST_DATA]

    @staticmethod
    def page_comparison_results():
        return []

    @staticmethod
    def create_analysis_structure():
        return ''

    def get_other_versions_of_firmware(self, fo):
        return []

    def is_firmware(self, uid):
        return uid == 'uid_in_db'

    def get_file_name(self, uid):
        if uid == 'deadbeef00000000000000000000000000000000000000000000000000000000_123':
            return 'test_name'
        if uid == TEST_FW.uid:
            return TEST_FW.file_name
        return None

    def get_summary(self, fo, selected_analysis, invert, focus=False):
        if fo.uid == TEST_FW.uid and selected_analysis == 'foobar':
            return {'foobar': ['some_uid']}
        return None

    # === Comparison ===

    @staticmethod
    def comparison_exists(comparison_id):
        return comparison_id == COMPARISON_ID

    @staticmethod
    def get_comparison_result(comparison_id):
        if comparison_id == COMPARISON_ID:
            return {
                'general': {'hid': {TEST_FW.uid: 'hid1', TEST_FW_2.uid: 'hid2'}},
                '_id': comparison_id,
                'submission_date': 0.0,
            }
        return None

    @staticmethod
    def objects_exist(compare_id):
        return compare_id in ['existing_id', 'uid1;uid2', COMPARISON_ID]

    @staticmethod
    def get_hid_dict(uid_set, root_uid):  # noqa: ARG004
        return dict.fromkeys(uid_set, 'hid')

    @staticmethod
    def get_file_tree_path(uid: str, root_uid=None):
        if root_uid:
            return [[root_uid, uid]]
        return [[uid]]


def fake_exit(self, *args):
    pass


def get_firmware_for_rest_upload_test():
    testfile_path = get_test_data_dir() / 'container/test.zip'
    with testfile_path.open('rb') as fp:
        file_content = fp.read()
    return {
        'binary': standard_b64encode(file_content).decode(),
        'file_name': 'test.zip',
        'device_name': 'test_device',
        'device_part': 'test_part',
        'device_class': 'test_class',
        'version': '1.0',
        'vendor': 'test_vendor',
        'release_date': '1970-01-01',
        'tags': '',
        'requested_analysis_systems': ['software_components'],
    }


def store_binary_on_file_system(tmp_dir: str, test_object: FileObject | Firmware):
    binary_dir = Path(tmp_dir) / test_object.uid[:2]
    binary_dir.mkdir(parents=True)
    (binary_dir / test_object.uid).write_bytes(test_object.file_path.read_bytes())


def setup_test_tables(db_setup):
    db_setup.connection.create_tables()
    db_setup.set_table_privileges()


def clear_test_tables(db_setup):
    db_setup.connection.base.metadata.drop_all(db_setup.connection.engine)


def generate_analysis_entry(
    plugin_version: str = '1.0',
    analysis_date: float = 0.0,
    summary: list[str] | None = None,
    tags: dict | None = None,
    analysis_result: dict | None = None,
):
    return {
        'plugin_version': plugin_version,
        'analysis_date': analysis_date,
        'summary': summary or [],
        'tags': tags or {},
        'result': analysis_result or {},
    }


def assert_search_result(response: TestResponse, included: list[FileObject], excluded: list[FileObject]):
    assert response.status_code == HTTPStatus.OK
    html = response.data.decode()
    assert 'Browse Firmware Database' in html, 'wrong page'
    assert 'Please enter a valid search request' not in html, 'error in query'
    for fo in included:
        assert f"href='/analysis/{fo.uid}'" in html, f'file {fo.uid} should be included in the result'
    for fo in excluded:
        assert f"href='/analysis/{fo.uid}'" not in html, f'file {fo.uid} should not be included in the result'


def wait_for_event(
    expression: Callable[[], bool], timeout: float = 5.0, check_interval: float = 0.1, inverted: bool = False
) -> bool:
    check: Callable[[], bool] = expression if not inverted else lambda: not expression()
    start_time = time.time()
    while time.time() - start_time < timeout:
        if check():
            return True
        time.sleep(check_interval)
    return check()
